
package accionesjugador;

import planetas.Planetas;




public class JugadorAcciones {
    
    

   
    
    //medir distancia entre planetas
    
  //Se mide disntancia entre los dos planetas 
    public  Double calcularDistancia(Planetas p1, Planetas p2){
        Double a = null; 
        Double b = null ;
        
        if ( p1 != null && p2 !=null){
        
        
        a = Math.pow((p2.getCoordenadaX() - p1.getCoordenadaX()), 2);
        b = Math.pow((p2.getCoordenadaY() - p1.getCoordenadaY()), 2);
       
      

        
    }else {
            
         return null; 
            
        }
      return Math.sqrt(a + b);
    }
    
    
    // ver planetas 
    //muestra los datos de los planetas netruales y conquistados  ingresador por x jugaror
    
    
    public void verPlanetas( int x , int y , Planetas posicion[][]) {
   
         Planetas  informacion = new Planetas();
      
              
        // se busca en la matriz  
    
         for (int i=0; i < posicion.length; i ++ ){
             for (int j =0; j < posicion[0].length; j ++   ){
                 
                 
                 if ( posicion[x][y] == posicion[i][j]){
                     
                     posicion[x][y].MostrarDatos();
                     
                     break; 
                 }
                 
                 else if ( posicion[x][y] != posicion[i][j]) {
                  System.out.println(" No existe un planeta con tales coordenadas");
                 break; 
                 }
                 
             }
         }
         
         
        
        
        
        
        
        
        
        // se depliegan los tados del palaneta neutral o de los conquistados

        
    }
    
    
    
    
        
    
    
    //  consultar flotas 
    
 
    public void consultarFlotas(){
        
        
        
    }
    
    

    
    
    
    //envio fotas 
    // las flotas se guardan en arreglos para su posterior visualziacion
    public void envioFlotas(){
        
        
    }
    


    //construir nave 
    
public void construirNaves(){
    
    
    
    }    
    
    
    
    
    
    
    
    //acesar a tienda 
    
    public void accesarTieda(){
    
        
    
    
    }

   
    

    
    //finaliza el turno de cada jugador 
    
    
    public void finaturno(String  nombreJugador ){
        
        
        System.out.println(" Jugador : " + nombreJugador + " ha terminado su turno ");
    }
    
    
    
    
    
    

    
    
    
    
    
    
}
