
package guerreros;

import naves.Naves;
import planetas.Planetas;


public class Mole extends Guerreros {

    public Mole(String nimbreGuerrero, float factorMuerte, int lugarOcupa) {
        super(nimbreGuerrero, factorMuerte, lugarOcupa);
    }
    
  
    public  Naves [] ocuparEspacioNave() {
          int espacio = 1 ; 
       
        Naves [] lugar = new Naves[espacio];
      
        return  lugar;
        
    }


    public String ataqueESpecial() {
        
        String ataqueEspecial= "Mole realiza su ataque especial! victimas enterradas";
       
        return  ataqueEspecial;
          
    }
    

    
//porecentajade  muerte de guerreri por la del planeta 
    public float factorMuerte(double  porcentajeMuerte ){
        float valorMuerte= (float) 1.5; 
    
        float resultado   = (float)porcentajeMuerte*  valorMuerte; 
        return resultado; 
    }
            
    
    
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
    
   
    
}
