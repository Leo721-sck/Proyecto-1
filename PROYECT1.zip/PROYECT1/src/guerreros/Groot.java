
package guerreros;

import naves.Naves;

public class Groot extends Guerreros{

    public Groot(String nimbreGuerrero, float factorMuerte, int lugarOcupa) {
        super(nimbreGuerrero, factorMuerte, lugarOcupa);
    }
    
  
   
 
     
    public  Naves [] ocuparEspacioNave() {
          int espacio = 3 ; 
       
        Naves [] lugar = new Naves[espacio];
      
        return  lugar;
        
    }


    public String ataqueESpecial() {
        
        String ataqueEspecial= " Groot realiza su ataque especial! enredaderas trampa activadas";
       
        return  ataqueEspecial;
          
    }
    

    
//porecentajade  muerte de guerreri por la del planeta 
    public float factorMuerte(double  porcentajeMuerte ){
        float valorMuerte= (float) 1.85; 
    
        float resultado   = (float)porcentajeMuerte*  valorMuerte; 
        return resultado; 
    }
            
      

 
   
    
        
    
    
 
   
 
    
    
    
  
}
