
package guerreros;

import naves.Naves;



public class Magma extends Guerreros {

    public Magma(String nimbreGuerrero, float factorMuerte, int lugarOcupa) {
        super(nimbreGuerrero, factorMuerte, lugarOcupa);
    }
    
  
     
    public  Naves [] ocuparEspacioNave() {
          int espacio = 2 ; 
       
        Naves [] lugar2 = new Naves[espacio];
      
        return  lugar2;
        
    }


    public String ataqueESpecial() {
        
        String ataqueEspecial= "Magma realiza su ataque especial! lanza sus feroces bolas de lava";
       
        return  ataqueEspecial;
          
    }
    

    
//porecentajade  muerte de guerreri por la del planeta 
    public float factorMuerte(double  porcentajeMuerte ){
        float valorMuerte= (float) 1.75; 
    
        float resultado   = (float)porcentajeMuerte*  valorMuerte; 
        return resultado; 
    }
               
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

}
