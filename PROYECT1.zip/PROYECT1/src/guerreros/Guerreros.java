
package guerreros;


public class Guerreros {


private String nombreGuerrero; 
private float factorMuerte;
private int lugarOcupa; 


//metodos 
//connstructor 

    public Guerreros(String nombreGuerrero, float factorMuerte, int lugarOcupa) {
        this.nombreGuerrero = nombreGuerrero;
        this.factorMuerte = factorMuerte;
        this.lugarOcupa = lugarOcupa;
    }

    public String getNombreGuerrero() {
        return nombreGuerrero;
    }

    public float getFactorMuerte() {
        return factorMuerte;
    }

    public int getLugarOcupa() {
        return lugarOcupa;
    }

    @Override
    public String toString() {
        return "Guerreros{" + "nombreGuerrero=" + nombreGuerrero + ", factorMuerte=" + factorMuerte + ", lugarOcupa=" + lugarOcupa + '}';
    }

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
  
    public void subirNave() {
       
        
    }
 
    
    public void atacer() {
      
        
    }

    
    public float calcularValormuerte(){
    float valorMuerte;
       
        return 1; 
    }
            
            
    
    
    
    
    
    
    
}
