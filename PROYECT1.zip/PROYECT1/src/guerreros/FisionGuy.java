
package guerreros;

import naves.Naves;



public class FisionGuy extends Guerreros {

    public FisionGuy(String nimbreGuerrero, float factorMuerte, int lugarOcupa) {
        super(nimbreGuerrero, factorMuerte, lugarOcupa);
    }
    
    
 
     
    public  Naves [] ocuparEspacioNave() {
          int espacio =  4 ; 
       
        Naves [] lugar = new Naves[espacio];
      
        return  lugar;
        
    }


    public String ataqueESpecial() {
        
        String ataqueEspecial= "Fision Guy realiza su ataque especial! lor rayos gamma han derretido al adversario";
       
        return  ataqueEspecial;
          
    }
    

    
//porecentajade  muerte de guerreri por la del planeta 
    public float factorMuerte(double  porcentajeMuerte ){
        float valorMuerte= (float) 1.95; 
    
        float resultado   = (float)porcentajeMuerte*  valorMuerte; 
        return resultado; 
    }
            
    
    
    
}
