
package guerreros;

import naves.Naves;


public class Nemo extends Guerreros {

    public Nemo(String nimbreGuerrero, float factorMuerte, int lugarOcupa) {
        super(nimbreGuerrero, factorMuerte, lugarOcupa);
    }
    
   
  
   
 
     
    public  Naves [] ocuparEspacioNave() {
          int espacio = 1 ; 
       
        Naves [] lugar = new Naves[espacio];
      
        return  lugar;
        
    }


    public String ataqueESpecial() {
        
        String ataqueEspecial= "Nemo realiza su ataque especial! lanza su poderoso chorro venenoso";
       
        return  ataqueEspecial;
          
    }
    

    
//porecentajade  muerte de guerreri por la del planeta 
    public float factorMuerte(double  porcentajeMuerte ){
        float valorMuerte= (float) 1.6; 
    
        float resultado   = (float)porcentajeMuerte*  valorMuerte; 
        return resultado; 
    }
            


    
}