
package diseñomapa;

import java.util.Random;

import java.util.Scanner;

import planetas.PlanetaInicial;
import planetas.PlanetaNeutral;
import planetas.Planetas;



//////////////////////////////////////////////////////////////////////////////////
public class DiseñoMapa {
    
     //Reset
  public static final String ANSI_RESET = "\u001B[0m";
    //colores para el tabler  
     //Colores de letra
  public static final String ANSI_BLACK = "\u001B[30m";
  public static final String ANSI_RED = "\u001B[31m";
  public static final String ANSI_GREEN = "\u001B[32m";
  public static final String ANSI_YELLOW = "\u001B[33m";
  public static final String ANSI_BLUE = "\u001B[34m";
  public static final String ANSI_PURPLE = "\u001B[35m";
  public static final String ANSI_CYAN = "\u001B[36m";
  public static final String ANSI_WHITE = "\u001B[37m";
  
//Colores de fondo
  public static final String ANSI_BLACK_BACKGROUND = "\u001B[40m"; 
  public static final String ANSI_RED_BACKGROUND = "\u001B[41m";
  public static final String ANSI_GREEN_BACKGROUND = "\u001B[42m";
  public static final String ANSI_YELLOW_BACKGROUND = "\u001B[43m";
  public static final String ANSI_BLUE_BACKGROUND = "\u001B[44m";
  public static final String ANSI_PURPLE_BACKGROUND = "\u001B[45m";
  public static final String ANSI_CYAN_BACKGROUND = "\u001B[46m";
  public static final String ANSI_WHITE_BACKGROUND = "\u001B[47m";
    
  ////////////////////////////////////////////////////////////////////////////////  
  
/////////////////Atributos/////////////////////////////////////////////////////////
 
    private String nombreJugador1; 
    private  String nombreJugador2; 
    private int nfilas; 
    private int nColumnas;
  
    private  int cantPlanetasNeutrales; 
    
    
    static Scanner teclado = new Scanner (System.in);

    
    
    public DiseñoMapa(String nombreJugador1, String nombreJugador2, int nfilas, int nColumnas) {
        this.nombreJugador1 = nombreJugador1;
        this.nombreJugador2 = nombreJugador2;
        this.nfilas = nfilas;
        this.nColumnas = nColumnas;
     
    }


    
    public DiseñoMapa() {
        
        
    }
    
  
    
    
    //////////////////////////////////Metodos ////////////////////////////////////////////////////////////
  
      
      

    
 
    
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // en el menu se deplegara  si se desea esta opcion o la otra xd
    
      public   Planetas  []  nuetralManual( int cantPlanetasNeutrales ){
  
             Planetas  []     planetasNetrales  = new Planetas [cantPlanetasNeutrales]; 
             
              //defino un arreglo para almacenar los planetas neutrales 
             
             
             for (int i  =0;  i <  cantPlanetasNeutrales ; i ++){
             
             System.out.println(" Introduzca nombre planeta ");
             char name1  = teclado.nextLine().charAt(0);
             System.out.println(" Cantidad Dinero");
             int diner  = teclado.nextInt(); 
             System.out.println(" Cantidad Constructores");
             int constructor =  teclado.nextInt(); 
             System.out.println("Cantidad naves ");
             int naves = teclado.nextInt(); 
             System.out.println("Cantidad Guerreros");
             int guerreros = teclado.nextInt(); 
             System.out.println(" tipo planeta");
             String tipoPlaneta =   teclado.next();
              
            
             
             planetasNetrales[i]= new PlanetaNeutral(name1, diner, constructor, naves, guerreros, tipoPlaneta  );
           //se guardaran estos atributos en un arreglo para su posterior visualizacion 
               }
              return planetasNetrales; 
         
         }  
    
    
    
  /////////////////////////////////////////////////////////////////////////////////////////////////////////  
    // la segunda opcion si no se quieren llenar los parametros
    
      public   Planetas []  neutralAutomatico( int cantPlanetasNeutrales ){
             
        Planetas [] automaticos = new PlanetaNeutral[cantPlanetasNeutrales] ;
          
          PlanetaNeutral automatico  = new PlanetaNeutral(); 
          
             for (int i  =0;  i <   cantPlanetasNeutrales ; i ++){
     
                 automatico.nombreAleatorio();
                 automatico.CantidadDiner(); 
                 automatico.CantidadConstructores();
                 automatico.CantidadNaves();

                 automaticos[i]= automatico; 
                 
      
                 }
            return  automaticos;  
      }
      
      
    /////////////////////////////////////////////////////////////////////////////////////////////  

  
      public  Planetas []  inicialManual  (){
    
         //defino un arreglo para almacenar los planetas iniciales
        Planetas [] planetasIniciales = new Planetas[2]; 

          
        for (int i  =0;  i < 2 ; i ++){
             System.out.println("\n");
             System.out.println(" Introduzca nombre  ");
             char name1  = teclado.next().charAt(0);
             System.out.println(" Cantidad Dinero");
             int diner  = teclado.nextInt(); 
             System.out.println(" cantidad Constructores");
             int constructor =  teclado.nextInt(); 
             System.out.println("Catnidad naves ");
             int naves = teclado.nextInt(); 
             System.out.println("Cantidad Guerreros");
             int guerreros = teclado.nextInt(); 
             System.out.println("Tipo planeta");
             String tipoPlaneta = teclado.next();
             
             planetasIniciales[i] = new PlanetaInicial( name1, diner, constructor, naves, guerreros, tipoPlaneta);
      
             //se guardaran estos atributos en un arreglo para su posterior visualizacion 
        }
      return planetasIniciales;
    
      }
    
      
      
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
      
    
      
      ///MOSTrAr DATOS DE PLANETAS NEUTRALES manuales xd 
      
      public void mostrarDatosNeutrales( PlanetaNeutral  [] planetasNetrales  ) {
          
      for (PlanetaNeutral planetasNetrale : planetasNetrales) {
          planetasNetrale.MostrarDatos();
      }

      }
      
      
      
      
      //MOSTAR DATOS PLANETAS NEUTRALES AUTOMATICOS 
      
      public void mostrarDatosNeutralesAutomaticos(  PlanetaNeutral [] automaticos ) {
          
      for (PlanetaNeutral automatico : automaticos) {
          automatico.MostrarDatos();
      }
          
      }
      
      
      
      
      
      /// MOSTRAR DATOS DE PLANETAS INICIALES 
      
      public void mostrarDatosIniciales( PlanetaInicial [] planetasIniciales){
      for (PlanetaInicial planetasIniciale : planetasIniciales) {
          planetasIniciale.MostrarDatos();
      }
          
      }
      

      
      
  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  
         
         
         //se cra un objeto del tipo planeta neutral 
         //se crea un objeto del tipo planeta inicial
        
   
      
//////////////////////////////////////////////////////////////////////////////////////////////////////
//SE GENERA EL TABLERO
      
      
   public  Planetas mostrarTablero (  String nombreJugador1, String nombreJugador2,
                   int nfilas, int nColumnas,Planetas [][] posicion , int cantPlanetasNeutrales   ){
       System.out.println("\n");
      
       System.out.println(ANSI_GREEN + "BIENVENIDO A KONQUEST"+ANSI_RESET );
       
       
       //Con esto se imprime la parte superior del cuadro
       for (int i = 0;  i < 138; i++)
            System.out.print("-");  
        System.out.println();
       
       
        
       //A partir de aquí se empiezan a imprimir los cuadros
        for (int y = 0; y <  nfilas; y++){
            int comprobador = 0;
            imprimirVacio(2 ,  nColumnas);           // imprime espacios vacios en el tablero       

            
         /////////////////////////////////////////////////////////////////////////////////////////////////////   
            //AQUI se imprime Dueño DEL PLANETA
            System.out.print("|");
            for (int x = 0; x <  nColumnas; x++) {
                if (posicion[y][x] == null)
                System.out.print(ANSI_BLUE_BACKGROUND +"                |");
                else{
                   
                    String name=  posicion[y][x].getPlayerName();
                    
                    if (name ==  nombreJugador1 ){
                    
                    System.out.print(ANSI_CYAN_BACKGROUND +" Dueño:"+ name + ANSI_RESET );
                    }
                    else if ( name ==  nombreJugador2){
                    System.out.print(ANSI_YELLOW_BACKGROUND+" Dueño:"+ name + ANSI_RESET );
                    }
                 
                    else if ( name != nombreJugador1 || name != nombreJugador2){
           
                     System.out.print(ANSI_PURPLE_BACKGROUND + " Neutral:"+ ANSI_RESET);  
                        
                    }
                    
               
                    
                    
                  
                    for (int i = 1; i < (7 ); i++)
                        System.out.print(" ");
                    System.out.print("|");
                }
            }
            System.out.println("");

            
            //AQUI IMPRIMIS Nombre DEL PLANETA
            System.out.print("|");
            for (int x = 0; x <  nColumnas; x++) {
                if (posicion[y][x] == null)
                    System.out.print(ANSI_BLUE_BACKGROUND +"                 |");
                else{
                  
                    char nomPlanetas =  posicion[y][x].getNombrePlaneta();
                    
                
                    System.out.print("     Nombre:");
                    for (int i = 1; i < (8 ); i++)
                        System.out.print(" ");
                    System.out.print("|");
                }
            }
            
            
    
    
            
            System.out.println();
            imprimirVacio(2,  nColumnas);
                
        //aqui se imprimen las barras horizontales
            for (int i = 0; i < 138; i++)
                System.out.print("-");
            System.out.println();
        }
        
           
            //SE MUETRAN LA OPCIONES QUE EL  JUGADOR PUEDE ELEGIR
            
         System.out.println("\n");
         System.out.println(" Estas son las acciones que puede ejecutar ");
         System.out.println("1.Medir distacia");
         System.out.println("2. Ver planeta ");
         System.out.println("4. Enviar flota ");
         System.out.println("5. Construir nave ");
         System.out.println("6. Tienda ");
         System.out.println("3. Consultar flota ");
         System.out.println("7. Finalizar turno ");
     
         
         return null;   
        
    }
   
   
   

    public static void imprimirVacio(int finI, int  nColumnas){

        for (int i = 0; i < finI; i++){
            System.out.print("|");
            for (int j = 0; j <  nColumnas; j++){
                System.out.print(ANSI_BLUE_BACKGROUND+"                |"+ANSI_RESET);
            }
            System.out.println();
        }

    }
 
  
        
        
        
        
    ////////////////////////////////////////////////////////////////////////////////////
  
    
    
    
    
    
    
    
    
    
       
       
   }    
      


      
      
      
      
      
      
      
      
