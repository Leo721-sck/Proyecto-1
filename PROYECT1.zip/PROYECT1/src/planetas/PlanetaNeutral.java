
package planetas;

public class PlanetaNeutral  extends Planetas {

    public PlanetaNeutral(char nombrePlaneta, int cantidadDiner, int cantidadConstructores, int cantidadNaves, int cantidadGuerreros, String  tipoPlaneta) {
        super(nombrePlaneta, cantidadDiner, cantidadConstructores, cantidadNaves, cantidadGuerreros, tipoPlaneta);
    }

 
    
    
    
    public PlanetaNeutral() {
    }

   

    
  
    
    
    
    
    
}
