
package planetas;

import guerreros.Guerreros;


public class Agua extends Planetas {
    
       private Guerreros tipoGuerrero; 

    public Agua(char nombrePlaneta, int cantidadDiner, int cantidadConstructores, int cantidadNaves, int cantidadGuerreros, String  tipoPlaneta) {
        super(nombrePlaneta, cantidadDiner, cantidadConstructores, cantidadNaves, cantidadGuerreros, tipoPlaneta);
    }

 
    public Agua (Guerreros tipoGuerrero ){
        
        this.tipoGuerrero = tipoGuerrero;
    }
 
   
    
    public Guerreros  tipoGuerrero (Guerreros Nemo)  {
       
       tipoGuerrero = Nemo; 
       return tipoGuerrero;
    }
    
    
    
      public float  ProbabilidadDistribucion() {
          
          float num = (float)(Math.random());
          
          if (num == 0.25  ){
          
                return num;
          }else{
              
              return 0; 
          }
          
    }
     
      
 
    
    


    
    //se generan guerreros entre 23 y 12
    public int guerrerosProducidos() {   
        
        int cantidadGuerreros= (int)(Math.random()*(23-12+1)+12);
        
        return cantidadGuerreros;
    }
    
    
    
       //genera dinero entre 60 y 120
    @Override
    public int CantidadDiner() {
        
        int cantidadDiner =  (int)(Math.random()*(120-60+1)+60);
        
        return cantidadDiner;
    }      

  
    
    
    
}
