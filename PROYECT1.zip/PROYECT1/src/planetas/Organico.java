
package planetas;

import guerreros.Guerreros;

public class Organico extends Planetas {

    
      private Guerreros tipoGuerrero; 
    public Organico(char nombrePlaneta, int cantidadDiner, int cantidadConstructores, int cantidadNaves, int cantidadGuerreros, String tipoPlaneta) {
        super(nombrePlaneta, cantidadDiner, cantidadConstructores, cantidadNaves, cantidadGuerreros, tipoPlaneta);
    }

    
    
    

    public Organico (Guerreros tipoGuerrero ){
        
        this.tipoGuerrero = tipoGuerrero;
    }
 
   
    
    public Guerreros  tipoGuerrero (Guerreros Groot)  {
       
       tipoGuerrero = Groot ; 
       return tipoGuerrero;
    }
    
    
    
      public float  ProbabilidadDistribucion() {
          
          float num = (float)(Math.random());
          
          if (num == 0.1  ){
          
                return num;
          }else{
              
              return 0; 
          }
          
    }
     
    
    
    //se generan guerreros entre 15 y 5
    public int guerrerosProducidos() {   
        
        int cantidadGuerreros= (int)(Math.random()*(15-5+1)+5);
        
        return cantidadGuerreros;
    }
    
    
    
       //genera dinero entre 80 y 160

    public int CantidadDiner() {
        
        int cantidadDiner =  (int)(Math.random()*(160-80+1)+80);
        
        return cantidadDiner;
    }      

  
    
    

    
}
