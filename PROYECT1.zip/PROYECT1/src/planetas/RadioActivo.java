
package planetas;

import guerreros.Guerreros;

public class RadioActivo extends Planetas{
    
    
    private Guerreros tipoGuerrero; 

    public RadioActivo(char nombrePlaneta, int cantidadDiner, int cantidadConstructores, int cantidadNaves, int cantidadGuerreros, String tipoPlaneta) {
        super(nombrePlaneta, cantidadDiner, cantidadConstructores, cantidadNaves, cantidadGuerreros, tipoPlaneta);
    }

   
    
    
    public RadioActivo (Guerreros tipoGuerrero ){
        
        this.tipoGuerrero = tipoGuerrero;
    }
 
   
    public Guerreros  tipoGuerrero (Guerreros FisionGuy)  {
       
       tipoGuerrero = FisionGuy ; 
       return tipoGuerrero;
    }
    
    
    
      public float  ProbabilidadDistribucion() {
          
          float num = (float)(Math.random());
          
          if (num == 0.05  ){
          
                return num;
          }else{
              
              return 0; 
          }
          
    }
     
    
    
    //se generan guerreros entre  9 y 3
    public int guerrerosProducidos() {   
        
        int cantidadGuerreros= (int)(Math.random()*(9-3+1)+3);
        
        return cantidadGuerreros;
    }
    
    
    
       //genera dinero entre  90 y 180
    @Override
    public int CantidadDiner() {
        
        int cantidadDiner =  (int)(Math.random()*(180-90+1)+90);
        
        return cantidadDiner;
    }      

  
    
    
    
    
    
    
}
