
package planetas;

import guerreros.Guerreros;
import java.util.Random;


public class Planetas {
      private int coordenadaX, coordenadaY;
    // hay neutrales  e iniciales 
     private char nombrePlaneta; 
     private int cantidadDiner;             //se genera aleatoriamente entre 100 y 500 
     private  int cantidadConstructores;    //su valoriniciale es de 1  el iniicial es el obreo
     private int cantidadNaves;             // se genera aleatoriamente entre 1 y 3 y es el naboo . n1 
     private int cantidadGuerreros;         //se genera basado en el planeta 
 
    private  final double  porcentajeMuerte = (Math.random()*0.1);
     
    private String  tipoPlaneta;  
    
    private String playerName; 
    private String  neutro; 
      
     Random  numAleatorio = new Random (); 
     //metodos  
     //constructor 

    public Planetas(char nombrePlaneta, int cantidadDiner, int cantidadConstructores, int cantidadNaves, int cantidadGuerreros,  String  tipoPlaneta) {
        this.nombrePlaneta = nombrePlaneta;
        this.cantidadDiner = cantidadDiner;
        this.cantidadConstructores = cantidadConstructores;
        this.cantidadNaves = cantidadNaves;
        this.cantidadGuerreros = cantidadGuerreros;
        this.tipoPlaneta = tipoPlaneta; 
     
    }
    
    
    
    public void setCoordenadaX(int coordenadaX) {
        this.coordenadaX = coordenadaX;
    }

    public void setCoordenadaY(int coordenadaY) {
        this.coordenadaY = coordenadaY;
    }

    public int getCoordenadaX() {
        return coordenadaX;
    }

    public int getCoordenadaY() {
        return coordenadaY;
    }

    
    
    
    
    
    
    
    
    
    
    
    
    public Planetas ( String playerName){
        this.playerName= playerName;
        
    }

    
    
    
    
   
    
    public void setNeutro(String neutro) {
        this.neutro = neutro;
    }

    public String getNeutro() {
        return neutro;
    }
    
    
  
    
    ////////////////////////////////////////////////////////////////

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    public String getPlayerName() {
        return playerName;
    }

  
 
    
    
    
    
    

    public void setNombre(char nombrePlaneta ) {
        this.nombrePlaneta = nombrePlaneta;
        
    }
                
        
    
    
    public char getNombrePlaneta() {
        return nombrePlaneta;
    }
    

    
    
  /////////////////////////////////////////////////////////////////////////////////////////////

    public void MostrarDatos() {
        System.out.println( "Planetas{" + "nombrePlaneta=" + nombrePlaneta 
                + ", cantidadDiner=" + cantidadDiner 
                + ", cantidadConstructores=" + cantidadConstructores 
                + ", cantidadNaves=" + cantidadNaves 
                + ", cantidadGuerreros=" + cantidadGuerreros 
                + ", porcentajeMuerte=" + porcentajeMuerte 
                + ", tipoPlaneta=" + tipoPlaneta + '}');
        
        
    }


    
    

    
    //////////////////////////////////////////////////////////////////// 
    // VALORES ALEATORIOS si no se defien de manera manual 
        
    public  Planetas () {
         
}
    
    
    
    
    
    
    public char nombreAleatorio() { 
        Random rando = new Random(); 
        
        String  nombreP  = ("ABCDEFGHIJKLMNÑOPQRSTUVWXYZ");
        
        char n = (char)rando.nextInt(nombreP.length()-1);
        this.nombrePlaneta = n;
        return  this.nombrePlaneta  ; 
    }
    
    

    //genera dinero entre 100 y 500
    public int CantidadDiner() {
        
        int cantidadDiner =  (int)(Math.random()*(500 -100+1)+100);
          this.cantidadDiner= cantidadDiner;
        
          return  this.cantidadDiner;
    }
      
  
   
    public String CantidadConstructores() {
        
        int cantiddadConstructores= 1; 
        String contructor= "obrero";       
       this.cantidadConstructores =  cantiddadConstructores;
        return  this.cantidadConstructores + "Obrero";
    }

   
    
    public int CantidadNaves() {
        
        int cantidadNaves=  (int)(Math.random()*3 +1 );
         this.cantidadNaves = cantidadNaves;
        
        return this.cantidadNaves;
    }

    

    
    
    
}
