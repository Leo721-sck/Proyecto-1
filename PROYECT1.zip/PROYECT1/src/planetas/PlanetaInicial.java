
package planetas;


public class PlanetaInicial extends Planetas{

    public PlanetaInicial(char nombrePlaneta, int cantidadDiner, int cantidadConstructores, int cantidadNaves, int cantidadGuerreros, String  tipoPlaneta) {
        super(nombrePlaneta, cantidadDiner, cantidadConstructores, cantidadNaves, cantidadGuerreros, tipoPlaneta);
    }

   
    public PlanetaInicial() {
    }

    
}