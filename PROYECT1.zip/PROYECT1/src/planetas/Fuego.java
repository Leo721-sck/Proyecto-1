
package planetas;

import guerreros.Guerreros;


public class Fuego extends Planetas{

    private Guerreros tipoGuerrero;
    
    
    public Fuego(char nombrePlaneta, int cantidadDiner, int cantidadConstructores, int cantidadNaves, int cantidadGuerreros, String tipoPlaneta) {
        super(nombrePlaneta, cantidadDiner, cantidadConstructores, cantidadNaves, cantidadGuerreros, tipoPlaneta);
    }

    public Fuego(Guerreros tipoGuerrero) {
        this.tipoGuerrero = tipoGuerrero;
    }

 
    
    

    
    public Guerreros  tipoGuerrero (Guerreros Magma)  {
       
       tipoGuerrero = Magma ; 
       return tipoGuerrero;
    }
    
   
    
    
      public float  ProbabilidadDistribucion() {
          
          float num = (float)(Math.random());
          
          if (num == 0.15  ){
          
                return num;
          }else{
              
              return 0; 
          }
          
    }
     
    
    
    //se generan guerreros entre 20 y 10
    public int guerrerosProducidos() {   
        
        int cantidadGuerreros= (int)(Math.random()*(20-10+1)+10);
        
        return cantidadGuerreros;
    }
    
    
    
       //genera dinero entre 70 y 140
    @Override
    public int CantidadDiner() {
        
        int cantidadDiner =  (int)(Math.random()*(140-70+1)+70);
        
        return cantidadDiner;
    }      

}
