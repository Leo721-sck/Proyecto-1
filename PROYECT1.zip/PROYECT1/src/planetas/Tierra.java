
package planetas;

import guerreros.Guerreros;




public class Tierra extends Planetas {

    private Guerreros tipoGuerrero; 

    public Tierra(char nombrePlaneta, int cantidadDiner, int cantidadConstructores, int cantidadNaves, int cantidadGuerreros, String tipoPlaneta) {
        super(nombrePlaneta, cantidadDiner, cantidadConstructores, cantidadNaves, cantidadGuerreros, tipoPlaneta);
    }

 
    public Tierra (Guerreros tipoGuerrero ){
        
        this.tipoGuerrero = tipoGuerrero;
    }
 
   
    
    public Guerreros  tipoGuerrero (Guerreros Mole)  {
       
       tipoGuerrero = Mole ; 
       return tipoGuerrero;
    }
    
    
    
      public float  ProbabilidadDistribucion() {
          
          float num = (float)(Math.random());
          
          if (num == 0.7  ){
          
                return num;
          }else{
              
              return 0; 
          }
          
    }
     
    
    
    //se generan guerreros entre 25 y 15
    public int guerrerosProducidos() {   
        
        int cantidadGuerreros= (int)(Math.random()*(25-15+1)+15);
        
        return cantidadGuerreros;
    }
    
    
    
       //genera dinero entre 50 y 100
    @Override
    public int CantidadDiner() {
        
        int cantidadDiner =  (int)(Math.random()*(100-50+1)+50);
        
        return cantidadDiner;
    }      

  
    
    
    
    
}