
package naves;


public class NabooN1 extends Naves {

    public NabooN1(float velocidadTransporte, Naves[] capacidadTransporte, String NombreNave, int costoProduccion) {
        super(velocidadTransporte, capacidadTransporte, NombreNave, costoProduccion);
    }

   
  
    public NabooN1(){
        
        
    }

    
    public Naves [] capacidadTranportar(){
        
        int espacio = 25 ;
        Naves [] espacioNave = new Naves [espacio];
        
        return espacioNave;
  
    }
    

    public int  CostoProducionNave(){
        int costroProduccionNave = 40;
        
        return costroProduccionNave; 
    }
 
       
  
    public  float velocidadTransporte(){
        
      float velovidadTrnsporte= 1;   
      
       return velovidadTrnsporte; 
    }

    
    
}
