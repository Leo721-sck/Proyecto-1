
package naves;


public class MillenialFalcon extends Naves{

    public MillenialFalcon(float velocidadTransporte, Naves[] capacidadTransporte, String NombreNave, int costoProduccion) {
        super(velocidadTransporte, capacidadTransporte, NombreNave, costoProduccion);
    }

    public MillenialFalcon() {
        
    }

   
    
    
    
    public Naves [] capacidadTranportar(){
        
        int espacio = 58 ;
        Naves [] espacioNave = new Naves [espacio];
        
        return espacioNave;
  
    }
    

    public int  CostoProducionNave(){
        int costroProduccionNave = 70;
        
        return costroProduccionNave; 
    }
 
       
  
    public  float velocidadTransporte(){
        
      float velovidadTrnsporte= (float) 1.5;   
      
       return velovidadTrnsporte; 
    }

    
    
    
    
    
    
    
    
}
