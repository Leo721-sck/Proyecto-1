
package naves;


public class StarDestroyer extends Naves {

    public StarDestroyer(float velocidadTransporte, Naves[] capacidadTransporte, String NombreNave, int costoProduccion) {
        super(velocidadTransporte, capacidadTransporte, NombreNave, costoProduccion);
    }

 
       
    public Naves [] capacidadTranportar(){
        
        int espacio = 80 ;
        Naves [] espacioNave = new Naves [espacio];
        
        return espacioNave;
  
    }
    

    public int  CostoProducionNave(){
        int costroProduccionNave = 100;
        
        return costroProduccionNave; 
    }
 
       
  
    public  float velocidadTransporte(){
        
      float velovidadTrnsporte= (float) 1.75;   
      
       return velovidadTrnsporte; 
    }

    
  
    

}
