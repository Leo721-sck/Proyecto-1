
package naves;



public class Xwing extends Naves {

    public Xwing(float velocidadTransporte, Naves[] capacidadTransporte, String NombreNave, int costoProduccion) {
        super(velocidadTransporte, capacidadTransporte, NombreNave, costoProduccion);
    }

    public Xwing() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   
    
    public Naves [] capacidadTranportar(){
        
        int espacio = 42 ;
        Naves [] espacioNave = new Naves [espacio];
        
        return espacioNave;
  
    }
    

    public int  CostoProducionNave(){
        int costroProduccionNave = 50;
        
        return costroProduccionNave; 
    }
 
       
  
    public  float velocidadTransporte(){
        
      float velovidadTrnsporte= (float) 1.25;   
      
       return velovidadTrnsporte; 
    }

    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
