
package naves;


 
public class Naves {
    
    //atributps 
    private  float  velocidadTransporte;
    private Naves[] capacidadTransporte; 
    private String NombreNave; 
    private int costoProduccion; 
    
    
    
    //metodos
    //cosntructor
    public Naves(float velocidadTransporte, Naves[] capacidadTransporte, String NombreNave, int costoProduccion) {
        this.velocidadTransporte = velocidadTransporte;
        this.capacidadTransporte = capacidadTransporte;
        this.NombreNave = NombreNave;
        this.costoProduccion = costoProduccion;
    }

    
  public Naves (){
     
  }
    
    
    
    
    
    public float getVelocidadTransporte() {
        return velocidadTransporte;
    }

    public Naves[] getCapacidadTransporte() {
        return capacidadTransporte;
    }

    public String getNombreNave() {
        return NombreNave;
    }

    public int getCostoProduccion() {
        return costoProduccion;
    }
  
    
    
}
    
    
    
    
    
    
    
    