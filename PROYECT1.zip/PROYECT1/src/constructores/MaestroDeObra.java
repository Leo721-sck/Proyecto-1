
package constructores;

import naves.MillenialFalcon;
import naves.Naves;
import naves.Xwing;

public class MaestroDeObra extends Constructores{

    public MaestroDeObra(Constructores tripoConstructor, int tiempoConstruccion, int precioNaveConstructor) {
        super(tripoConstructor, tiempoConstruccion, precioNaveConstructor);
    }

 
    
        
    //turnos que toma hacer una nave 
    
    
  
    public Naves  tiempoContruccionNaves( int tiempoConstruccion )  {
           Naves construirNave = new Xwing();   
         
        if ( tiempoConstruccion  == 2 ){
             
        return construirNave; 
        }else 
            
        return null; 
    }
    
    
   //compra de naves

    public Naves precioCompraTienda() {
        
        Naves nave = new Xwing();  
        
        int precioCompra = 100;
        
    
        return  nave ; 
        
        
}

//venta de Naves 

    public int  venderNavesTienda() {
        
        int precioVenta= 70; 
  
        return precioVenta;
    }    
  

}
