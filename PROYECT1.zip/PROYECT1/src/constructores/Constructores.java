
package constructores;

import naves.Naves;


public class Constructores {
    private  Constructores  tripoConstructor; 
    private  int tiempoConstruccion;  // se da por turnos 
    private int precioNaveConstructor; // precio de las navas 
    private Naves[] nave; 


    
    
    
    //metodos 
    
   //constructor

    public Constructores(Constructores  tripoConstructor , int tiempoConstruccion, int precioNaveConstructor) {
        this.tripoConstructor = tripoConstructor;
        this.tiempoConstruccion = tiempoConstruccion;
        this.precioNaveConstructor = precioNaveConstructor;
    }

    
    
    public void setTripoConstructor(Constructores  tripoConstructor) {
        this.tripoConstructor = tripoConstructor;
    }

    public void setTiempoConstruccion(int tiempoConstruccion) {
        this.tiempoConstruccion = tiempoConstruccion;
    }

    public void setPrecioNaveConstructor(int precioNaveConstructor) {
        this.precioNaveConstructor = precioNaveConstructor;
    }
    

    
        public Constructores getTripoConstructor() {
        return tripoConstructor;
    }

    public int getTiempoConstruccion() {
        return tiempoConstruccion;
    }

    public int getPrecioNaveConstructor() {
        return precioNaveConstructor;
    }
    
    
    
  

    
}


