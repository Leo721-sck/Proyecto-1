
package constructores;

public class Tienda {
    
    private int CantidadArticulos; 
    private int precioArticulos; 
    private int compraArticulos; 

    public Tienda(int CantidadArticulos, int precioArticulos, int compraArticulos) {
        this.CantidadArticulos = CantidadArticulos;
        this.precioArticulos = precioArticulos;
        this.compraArticulos = compraArticulos;
    }
    
    
    
    
    public void VenderArticulos(String tipoConstructor, int PrecionaveConstructor){
            
            
            
            }
    
    public void ComprarArticulos(String  tipoConstructor, int PrecionaveConstructor){
        
        
        
    }
    
}