
package constructores;

import naves.MillenialFalcon;
import naves.Naves;


public class Arquitecto extends Constructores{

    public Arquitecto(Constructores tripoConstructor, int tiempoConstruccion, int precioNaveConstructor) {
        super(tripoConstructor, tiempoConstruccion, precioNaveConstructor);
    }

 

    
    
    //turnos que toma hacer una nave 
    
    
  
    public Naves  tiempoContruccionNaves( int tiempoConstruccion )  {
           Naves construirNave = new MillenialFalcon();  
         
        if ( tiempoConstruccion  == 1 ){
             
        return construirNave; 
        }else 
            
        return null; 
    }
    
    
   //compra de naves

    public Naves precioCompraTienda() {
        
        Naves nave = new MillenialFalcon();  
        
        int precioCompra = 250;
        
    
        return  nave ; 
        
        
}

//venta de Naves 

    public int  venderNavesTienda() {
        
        int precioVenta= 175; 
  
        return precioVenta;
    }    
  
    
    

    
    
}
