
package constructores;

import naves.NabooN1;
import naves.Naves;

public class Obrero extends Constructores {

    public Obrero(Constructores tripoConstructor, int tiempoConstruccion, int precioNaveConstructor) {
        super(tripoConstructor, tiempoConstruccion, precioNaveConstructor);
    }

 
    
    //turnos que toma hacer una nave 
    
    
  
    public Naves  tiempoContruccionNaves( int tiempoConstruccion )  {
           Naves construirNave = new NabooN1();  
         
        if ( tiempoConstruccion  == 3 ){
             
        return construirNave; 
        }else 
            
        return null; 
    }
    
    
    
    
    
    
    
      //compra de constructor

    public Naves precioCompraTienda() {
        
        Naves nave = new NabooN1();  
        
        int precioCompra = 50;
        
    
        return  nave ; 
        
        
}

//venta de constructor

    public int  venderNavesTienda() {
        
        int precioVenta= 40; 
  
        return precioVenta;
    }    
  
    
}
