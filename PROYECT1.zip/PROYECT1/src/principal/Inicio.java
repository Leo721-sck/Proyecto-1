
package principal;



import accionesjugador.JugadorAcciones;
import java.util.Scanner;
import diseñomapa.DiseñoMapa; 
import java.util.Random;
import planetas.PlanetaInicial;
import planetas.PlanetaNeutral;
import planetas.Planetas;


/// logica del programa 
public class Inicio {
    
    //aqui se genera lo iniical 
  public   String nombreJugador1; 
  public   String nombreJugador2; 
  public   int nfilas; 
  public   int nColumnas;
  public   int cantPlanetasNeutrales; 
  
Planetas []  inicialManual;
Planetas []  automaticos;
Planetas []  planetasNetrales ;






    
   public static Scanner teclado = new Scanner (System.in);
   public static final String ANSI_RED = "\u001B[31m";
    
    //genero un objeto de la clase diseño mapa 
    
    // se iniica lo primero 
    
    
    public void inicio(){
        
        
        
 
        System.out.println(" NombreJugador 1 ");
        nombreJugador1 = teclado.nextLine(); 
  
        System.out.println(" NombreJugador 2 ");
        nombreJugador2 = teclado.nextLine(); 
     
        System.out.println("Diseño de tamaño Mapa");       
        System.out.println("Cuantas filas Desea ? ");
         nfilas = teclado.nextInt(); 
        
         System.out.println("Cuantas Columnas Desea?  ");
         nColumnas = teclado.nextInt();
         
         System.out.println("cuantos planetas netruales desea? ");
         cantPlanetasNeutrales = teclado.nextInt(); 
 
         
         
         DiseñoMapa generar = new  DiseñoMapa(); 
         
         
         Planetas [][]  posicion = new Planetas[ nfilas][ nColumnas]; 
   
         Planetas p1  = new Planetas() ;  
         Planetas p2  = new Planetas() ;
         Planetas p3  = new Planetas();
         
         p1.setPlayerName( nombreJugador1 );
         p2.setPlayerName(nombreJugador2 );
        // p3.setNeutro("Dueño");
         
         int e; 
         int r; 
         int m; 
         int n; 
         int q;
         int p; 
         int cont =0; 
         Random ran = new Random() ; 
         
         e = ran.nextInt(nfilas-1); 
         r = ran.nextInt(nColumnas-1);
         m = ran.nextInt(nfilas-2);
         n = ran.nextInt(nColumnas-2);
         q = ran.nextInt(posicion.length); 
         p = ran.nextInt(posicion[0].length-1);
     
            posicion[e][r]= p1;
            posicion[m][n]= p2;
    
    
        //SE GENERAN POSICIONES ALEATORIAS PARA LA N CANTIDAD DE PLANETAS NEUTRALES
                       for( int k= 0; k <   cantPlanetasNeutrales  ; k ++){
                    
                     posicion[p+ cont][q]= p3;
                   
                        cont ++;  
                
                   }
         
          
            
            
     
        
         
         // se generan las dos opciones          
       
         int opcion=0; 
        
         System.out.println();     
         System.out.println(" Desea especificar atributos de los planetas Neutrales ?");
         System.out.println("1. Si deseo");
         System.out.println("2. No deseo");
         opcion = teclado.nextInt();
          
         
         
         
         switch(opcion){
          
             // ir al atributo del objeto diseñar para poder generar atriubutos de la bariabl
             
             
             case  1 : 
                
                 
                 System.out.println("generando valores manuales");
               
                 
         planetasNetrales = generar.nuetralManual(cantPlanetasNeutrales);
                   break; 

         
             // los atributos se generan de manera autimatica 
             case 2 : 
            System.out.println("generandovalores aleatorios");
            automaticos = generar.neutralAutomatico( cantPlanetasNeutrales);
             break ; 
             
             
             default : 
                 
                 System.out.println(" Intruduzca un valor correcto");
                 
             break; 
         }        
          
         
      
       ///////////////////////////////////////////////////////////////////
 
         
        
         
         //se llenan los valores de los planetas iniciales 
         System.out.println(); 
         System.out.println("\n");
         
        System.out.println("Establezca los Atributos de los Planetas Iniciales");
       
             inicialManual =  generar.inicialManual();

       System.out.println("\n");
   
       // se debe mostar tablero con los valores establecidos
           
   
       generar.mostrarTablero(nombreJugador1, nombreJugador2, nfilas, nColumnas, posicion, cantPlanetasNeutrales );
 
        
 ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
     
//  se inicial la logia del game los jugadores entran en accion 
      
    int seleccion1=0;
    int seleccion2 =0;

    int contador ; 
    contador =0; 
    int terminarGame=0; 
    
    int x; 
    int y;     
    int M ; 
    int N ;
 
    JugadorAcciones  j1 = new JugadorAcciones() ; 
    JugadorAcciones  j2 = new JugadorAcciones();  

     
 
    
    do{
     

            do {

        System.out.println("\n");
        System.out.println("El turno es de " + nombreJugador1);
        seleccion1= teclado.nextInt();


              
                //se ejecuta los turnos para el jugador 1
                switch (seleccion1) {
                    case 1:
                 
                        
                        //se mide distancia entre planetas
                     System.out.println(" Ingrese la ubicacion del planeta  origen");
                     System.out.println("ingrese coordenada en X del planeta 1");
                     p1.setCoordenadaX(teclado.nextInt());
                     System.out.println("Ingrese coordenada en Y del planeta 1");
                     p1.setCoordenadaY(teclado.nextInt());
                         
             
                         posicion[p1.getCoordenadaY()] [p1.getCoordenadaX()]=  p1;
                  
                     System.out.println(" Inse la ubicacion del planeta destino");
                     
  


                    System.out.println("Ingrese coordenada en X del planeta 2");
                    p2.setCoordenadaX(teclado.nextInt());
                    System.out.println("Ingrese coordenada en Y del planeta 2");
                    p2.setCoordenadaY(teclado.nextInt());   

                     posicion[p2.getCoordenadaY()] [p2.getCoordenadaX()]= p2; 
                     
                  if ( j1.calcularDistancia( p1, p2) == null){
                             
                             System.out.println(" Las coordenadas de los planeetas son erroneos");
                         } else{
                         
                         
                      
                 System.out.println("\n\n\nLa distancia entre el planeta origen " 
                         + " y el planeta destino  " + " es de: " 
                         +j1.calcularDistancia( p1, p2)
                         + "  años luz " );
                                
                         }
                       break ;
                    
                    
                    case 2:
        // se caclula distancia ente planetas 

                        System.out.println(" Ingrese  la ubicacion del palaneta ");
                
                        System.out.println(" ingrese el numero de fila");

                        x = teclado.nextInt(); 

                        System.out.println(" ingrese el numeto de columna ");
                        y = teclado.nextInt(); 

                    j1.verPlanetas(x, y , posicion);
                        
                        break ;
                    case 3:
                        j1.consultarFlotas();
                        break;
                    case 4:
                        j1.envioFlotas();
                        break ;
                    case 5:
                        j1.construirNaves();
                        break ;
                    case 6:
                        j1.accesarTieda();
                        break;
                    case 7:
                        j1.finaturno( nombreJugador1);
                    
                        
                        break ;
                    default:
                        System.out.println(" Escoga una opcion valida!");
                        break ;
                }
                
                
                
            } while (seleccion1 <  7 || seleccion1 > 7); 
   
    
/////////////////////////////////////////////////////////////////////////////////////////

    //se ejecutan los turnos para el jugador 2 
 

        
        
            do {

        System.out.println("\n");
        System.out.println("El turno es de " + nombreJugador2);
        seleccion2 = teclado.nextInt();


              
                //se ejecuta los turnos para el jugador 1
                switch (seleccion2) {
                    case 1:
                        
                  
                             //se mide distancia entre planetas         
                                    
                    System.out.println(" Ingrese la ubicacion del planeta  origen");
                        
                 
                    System.out.println("ingrese coordenada en X del planeta 1");
                    p1.setCoordenadaX(teclado.nextInt());
                    System.out.println("Ingrese coordenada en Y del planeta 1");
                    p1.setCoordenadaY(teclado.nextInt());
                         
             
                     posicion[p1.getCoordenadaY()][p1.getCoordenadaX()]= p1;
                  
                     System.out.println(" Inse la ubicacion del planeta destino");
                     
  


                    System.out.println("Ingrese coordenada en X del planeta 2");
                    p2.setCoordenadaX(teclado.nextInt());
                    System.out.println("Ingrese coordenada en Y del planeta 3");
                    p2.setCoordenadaY(teclado.nextInt() );   

                     posicion[p2.getCoordenadaY()][p2.getCoordenadaX()]= p2; 
                     
                  if ( j1.calcularDistancia( p1, p2) == null){
                             
                             System.out.println(" Las coordenadas de los planeetas son erroneos");
                         } else{
                         
                         
                      
                 System.out.println("\n\n\nLa distancia entre el planeta origen " 
                         + " y el planeta destino  " + " es de: " 
                         +j1.calcularDistancia( p1, p2)
                         + "  años luz " );
                                
                         }
                       break ;
                    
                    case 2:
                        
                        // se caclula distancia ente planetas 
                    
                        System.out.println(" Ingrese  la ubicacion del palaneta ");
                       
                        System.out.println(" ingrese el numero de fila");
 
                        x = teclado.nextInt(); 

                        System.out.println(" ingrese el numero de columna ");
                        y = teclado.nextInt(); 

        
                    j2.verPlanetas(x, y, posicion);
                        
                        break ;
                    case 3:
                        
                        j2.consultarFlotas();
                        break;
                    case 4:
                        
                        j2.envioFlotas();
                        
                        
                        break ;
                    case 5:
                        
                        j2.construirNaves();
                        break ;
                    case 6:
                        
                        j2.accesarTieda();
                        break;
                    case 7:
                        
                        j2.finaturno( nombreJugador1);
                    
                        
                        break ;
                    default:
                        System.out.println(" Escoga una opcion valida!");
                        break ;
                }
                
                
                
            } while (seleccion2 <7 || seleccion2 >7 ); 
   

    
//////////////////////////////////////////////////////////////////////////////////////////////////}
//contador
        if (  seleccion1 ==7 && seleccion2==7){
          
           contador++; 
            System.out.println("\n");
            System.out.println("\n");
            System.out.println(    ANSI_RED + " Numero de truno  " + contador);   
            
        } 
    
     
     
    } while(terminarGame >20 || terminarGame< 20);
        
 ////////////////////////////////////////////////////////////////////////////////////////////

    }

}
    
