
package proyect1;

import principal.Inicio;


public class MAIN {

  
    public static void main(String[] args) {
    
        Inicio empieza = new Inicio() ;
        empieza.inicio();
        
        
    }
        
    
}
